# ИНИЦИАЛИЗАЦИЯ КЛАССА, В КОТОРЫЙ СОХРАНЯЕТСЯ CSV ФАЙЛ

class Packet:
    def __init__(self, time, time_delta, time_delta_disp, time_relative, time_epoch, length, ip_src, ip_dst, df,
                 mf, rb, src_port, dst_port, ack, syn, fin, clas):
        # self.number = number
        self.time = time
        self.time_delta = time_delta
        self.time_delta_disp = time_delta_disp
        self.time_relative = time_relative
        self.time_epoch = time_epoch
        self.length = length
        self.ip_src = ip_src
        self.ip_dst = ip_dst
        self.df = df
        self.mf = mf
        self.rb = rb
        self.src_port = src_port
        self.dst_port = dst_port
        self.ack = ack
        self.syn = syn
        self.fin = fin
        self.clas = clas

    def __repr__(self):
        return "В этом классе содержатся поля пакета"

    def __str__(self):
        return "В этом классе содержатся поля пакета"


### ИНИЦИАЛИЗАЦИЯ КЛАССА, ЭКЗЕМПЛЯРЫ КОТОРОГО БУДУТ ОТВЕЧАТЬ ЗА ХАРАКТЕРИСТИКИ
### ПАКЕТОВ НА ИНТЕРВАЛАХ


class Interval:
    def __init__(self, length, mean_length, min_length, max_length, intens, syn, ack, fin, unique_ip, intens_bit,
                 ip_src, ip_dst, src_port, dst_port, classification, unique_port):
        self.length = length
        self.mean_length = mean_length
        self.min_length = min_length
        self.max_length = max_length
        self.intens = intens
        self.syn = syn
        self.ack = ack
        self.fin = fin
        self.unique_ip = unique_ip
        self.intens_bit = intens_bit
        self.ip_src = ip_src
        self.ip_dst = ip_dst
        self.src_port = src_port
        self.dst_port = dst_port
        self.classification = classification
        self.unique_port = unique_port

        def __repr__(self):
            return "Экзмепляры этого класса отвечают за поля пакета на интервалах наблюдения"

        def __str__(self):
            return "Экзмепляры этого класса отвечают за поля пакета на интервалах наблюдения"



        ### создание класса для 4-х функций у каждого парамерта
class Default:
    def __init__(self, mean_ln_k_assim, mean_ln_k_eks, mean_ln_kontr, mean_ln_en_k, min_ln_k_assim, min_ln_k_eks,
                 min_ln_kontr, min_ln_en_k, max_ln_k_assim, max_ln_k_eks, max_ln_kontr, max_ln_en_k, intens_bit_k_assim,
                 intens_bit_k_eks, intens_bit_kontr, intens_bit_en_k, intens_p_k_assim, intens_p_k_eks, intens_p_kontr,
                 intens_p_en_k, unique_ip_k_assim, unique_ip_k_eks, unique_ip_kontr, unique_ip_en_k,
                 unique_port_k_assim, unique_port_k_eks, unique_port_kontr, unique_port_en_k, classific):
        self.mean_ln_k_assim = mean_ln_k_assim
        self.mean_ln_k_eks = mean_ln_k_eks
        self.mean_ln_kontr = mean_ln_kontr
        self.mean_ln_en_k = mean_ln_en_k
        self.min_ln_k_assim = min_ln_k_assim
        self.min_ln_k_eks = min_ln_k_eks
        self.min_ln_kontr = min_ln_kontr
        self.min_ln_en_k = min_ln_en_k
        self.max_ln_k_assim = max_ln_k_assim
        self.max_ln_k_eks = max_ln_k_eks
        self.max_ln_kontr = max_ln_kontr
        self.max_ln_en_k = max_ln_en_k
        self.intens_bit_k_assim = intens_bit_k_assim
        self.intens_bit_k_eks = intens_bit_k_eks
        self.intens_bit_kontr = intens_bit_kontr
        self.intens_bit_en_k = intens_bit_en_k
        self.intens_p_k_assim = intens_p_k_assim
        self.intens_p_k_eks = intens_p_k_eks
        self.intens_p_kontr = intens_p_kontr
        self.intens_p_en_k = intens_p_en_k

        self.unique_ip_k_assim = unique_ip_k_assim
        self.unique_ip_k_eks = unique_ip_k_eks
        self.unique_ip_kontr = unique_ip_kontr
        self.unique_ip_en_k = unique_ip_en_k

        self.unique_port_k_assim = unique_port_k_assim
        self.unique_port_k_eks = unique_port_k_eks
        self.unique_port_kontr = unique_port_kontr
        self.unique_port_en_k = unique_port_en_k

        self.classific = classific
