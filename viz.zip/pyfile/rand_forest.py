from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestClassifier
import pandas as pd
from matplotlib import pyplot as plt
import numpy as np
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.metrics import accuracy_score, recall_score, precision_score


def forest():
    ris = pd.read_csv('./csv/last.csv', delimiter=',')
    label1 = 'mean_ln_kontr'
    label2 = 'mean_ln_en_k'
    # new = pd.DataFrame(ris[label1], columns=[label1])
    # new[label2] = ris[label2]

    # X = new
    X = ris.drop('classif', axis='columns')
    y = ris['classif']
    X = X.to_numpy()
    y= y.to_numpy()
    #
    # pca = PCA(n_components=2)
    # X = pca.fit_transform(X)
    # print('X fit:', X)

    X_train, X_test, Y_train, Y_test = train_test_split(X, y, test_size=0.4, random_state=1234)
    forest = RandomForestClassifier(criterion='entropy', min_samples_split=0.15, max_features=10, n_estimators=100, n_jobs=-1, random_state=12345)
    forest.fit(X_train, Y_train)
    forest1 = RandomForestClassifier.predict(forest, X_test)

    print('forest:', round(forest.score(X_test, Y_test), 3))
    return accuracy_score(Y_test, forest1), precision_score(Y_test, forest1, zero_division=1), recall_score(Y_test, forest1)
