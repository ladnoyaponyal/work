import ctypes
import os
import platform
import sys

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QLabel, QLineEdit, QComboBox, \
    QFileDialog, QGridLayout, QTableWidget, QProgressBar

# from modelcore import PandasModel
from pyfile.function import classification
from pyfile.run import start, fff
import pyqtgraph as pg
import warnings
from pyfile.svmt import OSVM, OSVM1
from pyfile.rand_forest import forest
from pyfile.treeofdiscision import tree
from pyfile.knn import KNN

warnings.filterwarnings("ignore")

## Switch to using white background and black foreground
pg.setConfigOption('background', 'w')
pg.setConfigOption('foreground', 'k')
from IPython.external.qt_for_kernel import QtGui


class Window2(QWidget):
    def __init__(self):
        super(Window2, self).__init__()
        self.setWindowTitle('stats_feature')
        self.setGeometry(800, 800, 800, 800)

        self.lab0 = QLabel(self)
        self.lab0.setText('DFx: ')
        self.combo0 = QComboBox()
        self.combo0.addItems(['mean_ln_', 'min_ln_', 'max_ln_', 'intens_p_', 'intens_bit_', \
                              'unique_ip_', 'unique_port_'])

        self.lab1 = QLabel(self)
        self.lab1.setText('DFy: ')
        self.combo1 = QComboBox()
        self.combo1.addItems(['mean_ln_', 'min_ln_', 'max_ln_', 'intens_p_', 'intens_bit_', \
                              'unique_ip_', 'unique_port_'])
        self.lab2 = QLabel(self)
        self.lab2.setText('x: ')
        self.combo2 = QComboBox()
        self.combo2.addItems(['k_assim', 'k_eks', 'kontr', 'en_k'])

        self.lab3 = QLabel(self)
        self.lab3.setText('y: ')
        self.combo3 = QComboBox()
        self.combo3.addItems(['k_assim', 'k_eks', 'kontr', 'en_k'])

        self.buttonW2 = QPushButton('Graph VIEW', self)
        self.count = 0
        self.buttonW2.clicked.connect(self.view)

        self.view2 = pg.GraphicsLayoutWidget()

        self.buttonSVM = QPushButton('LINEAR', self)
        self.buttonSVM.clicked.connect(self.but_svm)
        # self.buttonALL = QPushButton('all', self)
        # self.buttonALL.clicked.connect(self.but_all)

        self.buttonforest = QPushButton('forest', self)
        self.buttonforest.clicked.connect(self.but_forest)

        self.buttontree = QPushButton('tree', self)
        self.buttontree.clicked.connect(self.but_tree)

        self.table_widget1 = QTableWidget()

        # self.lineTEXT = QLineEdit(self)
        self.labelForest = QLabel(self)
        self.labelSVM = QLabel(self)
        self.labelTree = QLabel(self)
        self.labelKNN = QLabel(self)

        self.buttonKNN = QPushButton('KNN', self)
        self.buttonKNN.clicked.connect(self.but_knn)


        # self.lbl = QtGui.QTextBrowser(self)



        layout1 = QGridLayout()
        layout1.setSpacing(5)
        layout1.addWidget(self.lab0, 1, 0, 1,1, Qt.AlignCenter)
        layout1.addWidget(self.combo0, 1, 1, 1,1)
        layout1.addWidget(self.lab2,1 , 2, 1,1, Qt.AlignCenter)
        layout1.addWidget(self.combo2,1 ,3, 1,1)
        layout1.addWidget(self.lab1,2,0, 1,1, Qt.AlignCenter)
        layout1.addWidget(self.combo1,2,1,1,1)
        layout1.addWidget(self.lab3,2,2,1,1, Qt.AlignCenter)
        layout1.addWidget(self.combo3,2,3,1,1)
        layout1.addWidget(self.buttonW2)
        layout1.addWidget(self.view2,4,2,1,2)
        layout1.addWidget(self.table_widget1,4,0,1,2)
        # layout1.addWidget(self.lineTEXT, 4, 5,)
        # layout1.addWidget(self.lbl,4,5)
        layout1.addWidget(self.buttonSVM,5,0,1,1)
        layout1.addWidget(self.buttonforest, 5, 1, 1,1)
        layout1.addWidget(self.buttontree,5,2,1,1)
        # layout1.addWidget(self.buttonALL,5,3,1,1)
        layout1.addWidget(self.buttonKNN, 5, 3, 1, 1)
        layout1.addWidget(self.labelSVM,6,0,2,1)
        layout1.addWidget(self.labelForest,7, 1, 1,1)
        layout1.addWidget(self.labelTree, 7, 2, 1, 1)
        layout1.addWidget(self.labelKNN, 7, 3, 1, 1)




        self.setLayout(layout1)

    def view(self, count):
        global AxisX
        global AxisY
        AxisX = self.combo1.currentText() + self.combo2.currentText()
        AxisY = self.combo1.currentText() + self.combo3.currentText()
        if self.count == 0:
            self.w1 = self.view2.addPlot()
            self.s = pg.ScatterPlotItem(x=new_res[0][AxisX], y=new_res[0][AxisY], pen='b')
            # self.s = pg.ScatterPlotItem(x=[x.mean_ln_en_k for x in itog[2]], y=[y.mean_ln_kontr for y in itog[2]], pen='b')
            self.count += 1
            self.w1.addItem(self.s)
            # self.w1.addItem(pg.ScatterPlotItem(x=[x.mean_ln_en_k for x in itog[3]], y=[y.mean_ln_kontr for y in itog[3]], pen='g'))
        else:
            self.s.clear()
            self.s = pg.ScatterPlotItem(x=new_res[0][AxisX], y=new_res[0][AxisY], pen='b')
            # self.s = pg.ScatterPlotItem(x=[x.mean_ln_en_k for x in itog[2]], y=[y.mean_ln_kontr for y in itog[2]], pen='b')
            self.w1.addItem(self.s)
            # self.w1.addItem(pg.ScatterPlotItem(x=[x.mean_ln_en_k for x in itog[3]], y=[y.mean_ln_kontr for y in itog[3]], pen='g'))

        headers = list(new_res[0])
        self.table_widget1.setRowCount(new_res[0].shape[0])
        self.table_widget1.setColumnCount(new_res[0].shape[1])
        self.table_widget1.setHorizontalHeaderLabels(headers)

        # getting data from df is computationally costly so convert it to array first
        df_array = new_res[0].values
        for row in range(new_res[0].shape[0]):
            for col in range(new_res[0].shape[1]):
                self.table_widget1.setItem(row, col, QtGui.QTableWidgetItem(str(df_array[row, col])))

        # self.w1.addItem(self.s)

    def but_svm(self):
        AxisX = self.combo0.currentText() + self.combo2.currentText()
        AxisY = self.combo1.currentText() + self.combo3.currentText()
        OSVM(AxisX, AxisY)

    def but_all(self):
        OSVM1()

    def but_forest(self):
        fore = forest()
        self.labelForest.setText(f'accuracy : {fore[0]}\n'
                                 f'preccision : {fore[2]}\n'
                                 f'recall : {fore[1]}')

    def but_tree(self):
        tr = tree(AxisX, AxisY)
        self.labelTree.setText(f'accuracy : {tr[0]}\n'
                                 f'preccision : {tr[1]}\n'
                                 f'recall : {tr[2]}')

    def but_knn(self):
        kn = KNN()
        self.labelKNN.setText(f'accuracy : {kn[0]}\n'
                                 f'preccision : {kn[1]}\n'
                                 f'recall : {kn[2]}')



class App(QWidget):

    def __init__(self, parent=None):
        super().__init__(parent)

        self.setWindowTitle('DATA_ANOMALY')
        self.setGeometry(800, 800, 800, 800)

        self.nameLabel0 = QLabel(self)
        self.nameLabel0.setText('Filename = ')

        self.nameLabel1 = QLabel(self)
        self.nameLabel1.setText('Time agregation = ')
        self.line1 = QLineEdit(self)

        # self.nameLabel2 = QLabel(self)
        # self.nameLabel2.setText('Step = ')
        # self.line2 = QLineEdit(self)

        self.button = QPushButton('Choose file and start', self)
        self.button.setToolTip('This is an example button')
        self.button.clicked.connect(self.on_click)
        # self.textEdit = QTextEdit()

        self.button2 = QPushButton('Graphs Visualizaton', self)
        self.button2.setToolTip('This is an example button')
        self.button2.clicked.connect(self.random_plot)

        self.cb = QComboBox()
        self.cb.addItems(["mean_ln", "min_ln", "max_ln", "intens_p", "intens_bit", \
                          "unique_ip", "unique_port", "syn", "fin", "ack"])
        self.view = view = pg.PlotWidget()
        self.curve = view.plot(name="Line")

        ###############################################
        self.nameLabel3 = QLabel(self)
        self.nameLabel3.setText('Next window agr interval = ')
        self.line3 = QLineEdit(self)

        self.nameLabel4 = QLabel(self)
        self.nameLabel4.setText('step = ')
        self.line4 = QLineEdit(self)

        self.button4 = QPushButton('GET_STAT_FEATURE', self)
        self.button4.setToolTip('This is an example button')
        self.button4.clicked.connect(self.next_agr)

        self.table_widget = QTableWidget()

        self.count1 = 0
        # self.view_bar = pg.PlotWidget()
        # self.buttonbar = QPushButton('LINEAR', self)
        # self.buttonbar.clicked.connect(self.bar)
        self.pbar = QProgressBar(self)
        self.pbar1 = QProgressBar(self)




        # self.cb.currentIndexChanged.connect(self.cb.changeEvent(self, self.random_plot))

        layout = QGridLayout()
        layout.setSpacing(5)
        layout.addWidget(self.nameLabel0, 1, 0, Qt.AlignCenter)
        layout.addWidget(self.nameLabel1, 2, 0, Qt.AlignCenter)
        layout.addWidget(self.line1, 2, 1, 1, 3)
        # layout.addWidget(self.nameLabel2, 3, 0, Qt.AlignCenter)
        # layout.addWidget(self.line2, 3, 1, 1, 3)
        layout.addWidget(self.button, 3, 0, 1, 4)
        layout.addWidget(self.pbar, 4, 0, 1, 4)
        layout.addWidget(self.button2, 5, 0, 1, 3)
        layout.addWidget(self.cb, 5, 3)
        layout.addWidget(self.view, 6, 2, 1, 2)
        layout.addWidget(self.table_widget, 6, 0, 1, 2)
        ###################
        layout.addWidget(self.nameLabel3, 7, 0, Qt.AlignCenter)
        layout.addWidget(self.line3, 7, 1, 1, 3)
        layout.addWidget(self.nameLabel4, 8, 0, Qt.AlignCenter)
        layout.addWidget(self.line4, 8, 1, 1, 3)
        layout.addWidget(self.button4, 9, 0, 1, 4)
        layout.addWidget(self.pbar1, 10,0,1,4 )

        ######3
        # layout.addWidget(self.view_bar)
        self.setLayout(layout)

    def next_agr(self):
        try:
            global new_res
            global itog
            a1 = 0
            self.pbar1.setValue(10)
            a2 = int(self.line3.text())
            self.pbar1.setValue(20)
            step = int(self.line4.text())
            self.pbar1.setValue(50)
            arr = res[1]
            new_res = fff(a1, a2, arr, step)
            self.pbar1.setValue(70)
            itog = classification(new_res[1])
            self.pbar1.setValue(100)
            self.w2 = Window2()
            self.w2.show()
        except:
            plt = platform.system()
            if plt == "Linux":
                os.system(f'''notify-send "NOTIFY" "USE ONLY INT MEANS"''')
            elif plt == "Windows":
                ctypes.windll.user32.MessageBoxW(0, "USE ONLY INT MEANS", "Notify", 0)

    def random_plot(self):
        self.curve.setData(x=range(len(res[0])), y=res[0][self.cb.currentText()], pen='b')
    def on_click(self):
        try:
            global k
            global step
            global res
            self.pbar.setValue(0)
            self.pbar1.setValue(0)
            k = float(self.line1.text())

            # step = float(self.line2.text())

            step = k
            fname = QFileDialog.getOpenFileName(self, 'Open file')
            self.nameLabel0.setText(f'Filename: {fname[0]}')
            self.pbar.setValue(30)
            res = start(k, step, fname[0])
            self.pbar.setValue(70)
            headers = list(res[0])
            self.table_widget.setRowCount(res[0].shape[0])
            self.table_widget.setColumnCount(res[0].shape[1])
            self.table_widget.setHorizontalHeaderLabels(headers)

            # getting data from df is computationally costly so convert it to array first
            df_array = res[0].values
            for row in range(res[0].shape[0]):
                for col in range(res[0].shape[1]):
                    self.table_widget.setItem(row, col, QtGui.QTableWidgetItem(str(df_array[row, col])))
            self.pbar.setValue(100)
        except:
            plt = platform.system()
            if plt == "Linux":
                os.system(f'''notify-send "NOTIFY" "USE ONLY INT OF FLOAT MEANS"''')
            elif plt == "Windows":
                ctypes.windll.user32.MessageBoxW(0, "USE ONLY INT OR FLOAT MEANS", "Notify", 0)


# def bar(self, count1):
    #     if self.count1 == 0:
    #         self.s = pg.BarGraphItem(x = range(len(res[0])) ,y = res[0][self.cb.currentText()], width=0.5, height=res[0][self.cb.currentText()],pen='b')
    #         self.count1 += 1
    #     else:
    #         self.s = pg.BarGraphItem(x = range(len(res[0])) ,y = res[0][self.cb.currentText()], width=0.5,height=res[0][self.cb.currentText()], pen='b')
    #         self.view_bar.addItem(self.s)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = App()
    ex.show()
    sys.exit(app.exec_())
