import numpy as np
import scipy.stats
import math

#### коэффициент ассметрии

def koef_assim(a):
    d = np.var(a, ddof=1)
    ka = (sum((xi - np.mean(a)) ** 3 for xi in a) / len(a)) / d ** 3
    if np.isnan(ka) or np.isinf(ka):
        return 0
    return ka


#### коэффициент эксцесса

def koef_eksces(a):
    d = np.var(a, ddof=1)
    ke = ((sum((xi - np.mean(a)) ** 4 for xi in a) / len(a)) / d ** 4) - 3
    if np.isnan(ke) or np.isinf(ke):
        return 0
    return ke


#### контрэксцесс

def kontrecsces(a):
    d = np.var(a, ddof=1)
    c = 1 / math.sqrt(scipy.stats.moment(a, moment=4) / (math.sqrt(d) ** 4))
    if np.isnan(c) or np.isinf(c):
        return 0
    return c


#### энтропийный коэффициент

def entr_koef(d, n, y, a):
    # n = len(a) число элементов в списке
    # m = int(10 + np.sqrt(n)) кол интервалов разбиения
    # d =(max(a)-min(a))/m длина интервалов
    h = 0.5 * d * n * 10 ** (-1 * (y * math.log10(y) / n))

    #     h = 0.5 * d * n * 10 ** (-sum ([w * math.log10 (w) for w in y if w != 0]) / n)
    h = h / a
    if np.isnan(h) or np.isinf(h):
        return 0
    return h
