### ЗАГРУЗКА НЕОБХОДИМЫХ БИБЛИОТЕК
from pylab import rcParams
rcParams['figure.figsize'] = 8, 5
from pyfile.function import fff, read_from_csv_2_array_object, wind_on_array_packet, classification, interv_2_csv
# from graph_build import build_graph, built2


def start(k2, step1, filename='./csv/not_atack.csv'):
    # read_from_csv_2_array_object(filename=filename)
    k1 = 0
    # k2 = float(input('Введите окно для анализа временного интервала = '))
    # step1 = float(input('Введите шаг окна = '))
    array = wind_on_array_packet(k=k2, step=step1, array_object_of_Packet=read_from_csv_2_array_object(filename))
    df = interv_2_csv(array)
    # ar_int = classification(array)
    return df, array
    # build_graph(df)
    # built2(df)




# itog_mas0 = []
# NUM0 = []
# itog_mas1 = []
# NUM1 = []
# k = fff(a1,a2,array_object_on_Interval)
# cnt = 0
# for c in k:
#     if c.classific == 0:
#         itog_mas0.append(c)
#         NUM0.append(cnt)
#     else:
#         itog_mas1.append(c)
#         NUM1.append(cnt)
#     cnt += 1
#
# print(len(itog_mas0), len(NUM0))
# print(len(itog_mas1), len(NUM1))
# print(len(k))
#

#
# print ('ГРАФИКИ ДЛЯ СРЕДНЕЙ ДЛИНЫ ПАКЕТА')
#
# #ассиметрия
# plt.subplot(111)
# plt.bar(NUM1, [c.mean_ln_k_assim for c in itog_mas1], color='r')
# plt.bar(NUM0, [c.mean_ln_k_assim for c in itog_mas0])
#
# plt.axis([0, len(NUM0) + len(NUM1), -0.00005, 0.00005])
# plt.xlabel('Отсчет')
# plt.ylabel('ss')
# plt.title('Ассиметрия')
# plt.minorticks_on()
# plt.grid()
# plt.show()
# # #
# #эксцесс
# # print(k_ek_ln)
# plt.subplot(111)
# plt.bar(NUM1, [c.mean_ln_k_eks for c in itog_mas1], color='r')
# plt.bar(NUM0, [c.mean_ln_k_eks for c in itog_mas0])
#
# # plt.bar(fff(a1, a2, mean_length)[13], fff(a1, a2, mean_length)[9], color='r')
# plt.xlabel('Отсчет')
# plt.ylabel('ss')
# plt.title('Эксцесса')
# plt.minorticks_on()
# plt.grid()
# plt.show()
# #
# # #контрэксцесс
# # #
# plt.subplot(111)
# plt.bar(NUM0, [c.mean_ln_kontr for c in itog_mas0])
# plt.bar(NUM1, [c.mean_ln_kontr for c in itog_mas1], color='r')
# # plt.bar(fff(a1, a2, mean_length)[13], fff(a1, a2, mean_length)[10], color='r')
# plt.xlabel('Отсчет')
# plt.ylabel('ss')
# plt.title('Контр Эксцесс')
# plt.minorticks_on()
# plt.grid()
# plt.show()
# # #
# # #энтропийный коэф
# # #
# plt.subplot(111)
# plt.bar(NUM1, [c.mean_ln_en_k for c in itog_mas1], color='r')
# plt.bar(NUM0, [c.mean_ln_en_k for c in itog_mas0])
#
# # plt.bar(fff(a1, a2, mean_length)[13], fff(a1, a2, mean_length)[11], color='r')
# # plt.axis([0, len(range(len(k))), 0, 0.8])
# plt.xlabel('Отсчет')
# plt.ylabel('ss')
# plt.title('Энтропийный коэф')
# plt.minorticks_on()
# plt.grid()
# plt.show()
# # #
# # #энтр коэф \ контр
# # #
# plt.subplot(111)
# plt.title('entr_k / kontr')
# plt.plot([c.mean_ln_en_k for c in itog_mas1], [c.mean_ln_kontr for c in itog_mas1] , 'r^')
# plt.plot([c.mean_ln_en_k for c in itog_mas0], [c.mean_ln_kontr for c in itog_mas0] , 'b*')
#
# # plt.plot(fff(a1, a2, mean_length)[11], fff(a1, a2, mean_length)[10], 'r^')
# plt.xlabel('entr_K')
# plt.ylabel('kontr')
# plt.show()
# # #
# # #ассим \ экс
# # #
# plt.subplot(111)
# plt.title('k_assim*2 / k_eks')
# plt.plot( [c.mean_ln_k_assim**2 for c in itog_mas1], [c.mean_ln_k_eks for c in itog_mas1], 'r^')
# plt.plot( [c.mean_ln_k_assim**2 for c in itog_mas0], [c.mean_ln_k_eks for c in itog_mas0], 'b*')
#
# # plt.plot([k**2 for k in fff(a1, a2, mean_length)[8]], fff(a1, a2, mean_length)[9], 'r^')
# plt.xlabel('k_assim**2')
# plt.ylabel('k_eks')
# plt.show()
# # #
# # #kont/entr
# # #
#
# plt.subplot(111)
# plt.title('kontr / entr_k')
# plt.xlabel('kontr')
# plt.ylabel('entr_k')
# plt.plot([c.mean_ln_kontr for c in itog_mas1], [c.mean_ln_en_k for c in itog_mas1] , 'r^')
# plt.plot([c.mean_ln_kontr for c in itog_mas0], [c.mean_ln_en_k for c in itog_mas0] , 'b*')
#
# # plt.plot(fff(a1, a2, mean_length)[10], fff(a1, a2, mean_length)[11], 'r^')
# plt.show()
# # #
# import plotly.graph_objs as go
# import plotly
# fig1 = go.Scatter3d(x=[c.mean_ln_en_k for c in itog_mas0], y=[c.mean_ln_k_assim for c in itog_mas0],                    z=[c.mean_ln_kontr for c in itog_mas0],                    marker=dict(opacity=0.9, reversescale=True,size=5),                    line=dict(width=0.2), mode='markers')
# fig2 = go.Scatter3d(x=[c.mean_ln_en_k for c in itog_mas1], y=[c.mean_ln_k_assim for c in itog_mas1],                    z=[c.mean_ln_kontr for c in itog_mas1],                    marker=dict(opacity=0.9, reversescale=True,size=5),                    line=dict(width=0.2), mode='markers')
# mylayout = go.Layout(scene=dict(xaxis=dict( title="entr_k"),
#                                 yaxis=dict( title="k_assim"),
#                                 zaxis=dict(title="kontr")),)
#
# #Plot and save html
# plotly.offline.plot({"data": [fig1, fig2],
#                      "layout": mylayout},
#                      auto_open=True,
#                      filename=("3DPlot.html"))
#
#
# # In[111]:
#
#
# print ('ГРАФИКИ ДЛЯ МАКСИМАЛЬНОЙ ДЛИНЫ ПАКЕТА')
#
# #ассиметрия
# plt.subplot(111)
# plt.bar(NUM1, [c.max_ln_k_assim for c in itog_mas1], color='r')
# plt.bar(NUM0, [c.max_ln_k_assim for c in itog_mas0])
#
# plt.axis([0, len(NUM0) + len(NUM1), -0.00005, 0.00005])
# plt.xlabel('Отсчет')
# plt.ylabel('ss')
# plt.title('Ассиметрия')
# plt.minorticks_on()
# plt.grid()
# plt.show()
# # #
# #эксцесс
# # print(k_ek_ln)
# plt.subplot(111)
# plt.bar(NUM1, [c.max_ln_k_eks for c in itog_mas1], color='r')
# plt.bar(NUM0, [c.max_ln_k_eks for c in itog_mas0])
#
# # plt.bar(fff(a1, a2, mean_length)[13], fff(a1, a2, mean_length)[9], color='r')
# plt.xlabel('Отсчет')
# plt.ylabel('ss')
# plt.title('Эксцесса')
# plt.minorticks_on()
# plt.grid()
# plt.show()
# #
# # #контрэксцесс
# # #
# plt.subplot(111)
# plt.bar(NUM1, [c.max_ln_kontr for c in itog_mas1], color='r')
# plt.bar(NUM0, [c.max_ln_kontr for c in itog_mas0])
#
# # plt.bar(fff(a1, a2, mean_length)[13], fff(a1, a2, mean_length)[10], color='r')
# plt.xlabel('Отсчет')
# plt.ylabel('ss')
# plt.title('Контр Эксцесс')
# plt.minorticks_on()
# plt.grid()
# plt.show()
# # #
# # #энтропийный коэф
# # #
# plt.subplot(111)
# plt.bar(NUM1, [c.max_ln_en_k for c in itog_mas1], color='r')
# plt.bar(NUM0, [c.max_ln_en_k for c in itog_mas0])
#
# # plt.bar(fff(a1, a2, mean_length)[13], fff(a1, a2, mean_length)[11], color='r')
# # plt.axis([0, len(range(len(k))), 0, 0.8])
# plt.xlabel('Отсчет')
# plt.ylabel('ss')
# plt.title('Энтропийный коэф')
# plt.minorticks_on()
# plt.grid()
# plt.show()
# # #
# # #энтр коэф \ контр
# # #
# plt.subplot(111)
# plt.title('entr_k / kontr')
# plt.plot([c.max_ln_en_k for c in itog_mas1], [c.max_ln_kontr for c in itog_mas1] , 'r^')
# plt.plot([c.max_ln_en_k for c in itog_mas0], [c.max_ln_kontr for c in itog_mas0] , 'b*')
#
# # plt.plot(fff(a1, a2, mean_length)[11], fff(a1, a2, mean_length)[10], 'r^')
# plt.xlabel('entr_K')
# plt.ylabel('kontr')
# plt.show()
# # #
# # #ассим \ экс
# # #
# plt.subplot(111)
# plt.title('k_assim*2 / k_eks')
# plt.plot( [c.max_ln_k_assim**2 for c in itog_mas1], [c.max_ln_k_eks for c in itog_mas1], 'r^')
# plt.plot( [c.max_ln_k_assim**2 for c in itog_mas0], [c.max_ln_k_eks for c in itog_mas0], 'b*')
#
# # plt.plot([k**2 for k in fff(a1, a2, mean_length)[8]], fff(a1, a2, mean_length)[9], 'r^')
# plt.xlabel('k_assim**2')
# plt.ylabel('k_eks')
# plt.show()
# # #
# # #kont/entr
# # #
#
# plt.subplot(111)
# plt.title('kontr / entr_k')
# plt.xlabel('kontr')
# plt.ylabel('entr_k')
# plt.plot([c.max_ln_kontr for c in itog_mas1], [c.max_ln_en_k for c in itog_mas1] , 'r^')
# plt.plot([c.max_ln_kontr for c in itog_mas0], [c.max_ln_en_k for c in itog_mas0] , 'b*')
#
# # plt.plot(fff(a1, a2, mean_length)[10], fff(a1, a2, mean_length)[11], 'r^')
# plt.show()
# # #
# import plotly.graph_objs as go
# import plotly
# fig1 = go.Scatter3d(x=[c.max_ln_en_k for c in itog_mas0], y=[c.max_ln_k_assim for c in itog_mas0],                    z=[c.max_ln_kontr for c in itog_mas0],                    marker=dict(opacity=0.9, reversescale=True,size=5),                    line=dict(width=0.2), mode='markers')
# fig2 = go.Scatter3d(x=[c.max_ln_en_k for c in itog_mas1], y=[c.max_ln_k_assim for c in itog_mas1],                    z=[c.max_ln_kontr for c in itog_mas1],                    marker=dict(opacity=0.9, reversescale=True,size=5),                    line=dict(width=0.2), mode='markers')
# mylayout = go.Layout(scene=dict(xaxis=dict( title="entr_k"),
#                                 yaxis=dict( title="k_assim"),
#                                 zaxis=dict(title="kontr")),)
#
# #Plot and save html
# plotly.offline.plot({"data": [fig1, fig2],
#                      "layout": mylayout},
#                      auto_open=True,
#                      filename=("3DPlot.html"))
#
#
# # In[113]:
#
#
# print ('ГРАФИКИ ДЛЯ МИНИМАЛЬНОЙ ДЛИНЫ ПАКЕТА')
#
# #ассиметрия
# plt.subplot(111)
# plt.bar(NUM1, [c.min_ln_k_assim for c in itog_mas1], color='r')
# plt.bar(NUM0, [c.min_ln_k_assim for c in itog_mas0])
#
# plt.axis([0, len(NUM0) + len(NUM1), -0.00005, 0.00005])
# plt.xlabel('Отсчет')
# plt.ylabel('ss')
# plt.title('Ассиметрия')
# plt.minorticks_on()
# plt.grid()
# plt.show()
# # #
# #эксцесс
# # print(k_ek_ln)
# plt.subplot(111)
# plt.bar(NUM1, [c.min_ln_k_eks for c in itog_mas1], color='r')
# plt.bar(NUM0, [c.min_ln_k_eks for c in itog_mas0])
#
# # plt.bar(fff(a1, a2, mean_length)[13], fff(a1, a2, mean_length)[9], color='r')
# plt.xlabel('Отсчет')
# plt.ylabel('ss')
# plt.title('Эксцесса')
# plt.minorticks_on()
# plt.grid()
# plt.show()
# #
# # #контрэксцесс
# # #
# plt.subplot(111)
# plt.bar(NUM1, [c.min_ln_kontr for c in itog_mas1], color='r')
# plt.bar(NUM0, [c.min_ln_kontr for c in itog_mas0])
#
# # plt.bar(fff(a1, a2, mean_length)[13], fff(a1, a2, mean_length)[10], color='r')
# plt.xlabel('Отсчет')
# plt.ylabel('ss')
# plt.title('Контр Эксцесс')
# plt.minorticks_on()
# plt.grid()
# plt.show()
# # #
# # #энтропийный коэф
# # #
# plt.subplot(111)
# plt.bar(NUM1, [c.min_ln_en_k for c in itog_mas1], color='r')
# plt.bar(NUM0, [c.min_ln_en_k for c in itog_mas0])
#
# # plt.bar(fff(a1, a2, mean_length)[13], fff(a1, a2, mean_length)[11], color='r')
# # plt.axis([0, len(range(len(k))), 0, 0.8])
# plt.xlabel('Отсчет')
# plt.ylabel('ss')
# plt.title('Энтропийный коэф')
# plt.minorticks_on()
# plt.grid()
# plt.show()
# # #
# # #энтр коэф \ контр
# # #
# plt.subplot(111)
# plt.title('entr_k / kontr')
# plt.plot([c.min_ln_en_k for c in itog_mas1], [c.min_ln_kontr for c in itog_mas1] , 'r^')
# plt.plot([c.min_ln_en_k for c in itog_mas0], [c.min_ln_kontr for c in itog_mas0] , 'b*')
#
# # plt.plot(fff(a1, a2, mean_length)[11], fff(a1, a2, mean_length)[10], 'r^')
# plt.xlabel('entr_K')
# plt.ylabel('kontr')
# plt.show()
# # #
# # #ассим \ экс
# # #
# plt.subplot(111)
# plt.title('k_assim*2 / k_eks')
# plt.plot( [c.min_ln_k_assim**2 for c in itog_mas1], [c.min_ln_k_eks for c in itog_mas1], 'r^')
# plt.plot( [c.min_ln_k_assim**2 for c in itog_mas0], [c.min_ln_k_eks for c in itog_mas0], 'b*')
#
# # plt.plot([k**2 for k in fff(a1, a2, mean_length)[8]], fff(a1, a2, mean_length)[9], 'r^')
# plt.xlabel('k_assim**2')
# plt.ylabel('k_eks')
# plt.show()
# # #
# # #kont/entr
# # #
#
# plt.subplot(111)
# plt.title('kontr / entr_k')
# plt.xlabel('kontr')
# plt.ylabel('entr_k')
# plt.plot([c.min_ln_kontr for c in itog_mas1], [c.min_ln_en_k for c in itog_mas1] , 'r^')
# plt.plot([c.min_ln_kontr for c in itog_mas0], [c.min_ln_en_k for c in itog_mas0] , 'b*')
#
# # plt.plot(fff(a1, a2, mean_length)[10], fff(a1, a2, mean_length)[11], 'r^')
# plt.show()
# # #
# import plotly.graph_objs as go
# import plotly
# fig1 = go.Scatter3d(x=[c.min_ln_en_k for c in itog_mas0], y=[c.min_ln_k_assim for c in itog_mas0],                    z=[c.min_ln_kontr for c in itog_mas0],                    marker=dict(opacity=0.9, reversescale=True,size=5),                    line=dict(width=0.2), mode='markers')
# fig2 = go.Scatter3d(x=[c.min_ln_en_k for c in itog_mas1], y=[c.min_ln_k_assim for c in itog_mas1],                    z=[c.min_ln_kontr for c in itog_mas1],                    marker=dict(opacity=0.9, reversescale=True,size=5),                    line=dict(width=0.2), mode='markers')
# mylayout = go.Layout(scene=dict(xaxis=dict( title="entr_k"),
#                                 yaxis=dict( title="k_assim"),
#                                 zaxis=dict(title="kontr")),)
#
# #Plot and save html
# plotly.offline.plot({"data": [fig1, fig2],
#                      "layout": mylayout},
#                      auto_open=True,
#                      filename=("3DPlot.html"))
#
#
# # In[114]:
#
#
# print ('ГРАФИКИ ДЛЯ УНИКАЛЬНЫХ АДРЕСОВ АЙПИ ПАКЕТА')
#
#
# #ассиметрия
# plt.subplot(111)
# plt.bar(NUM1, [c.unique_ip_k_assim for c in itog_mas1], color='r')
# plt.bar(NUM0, [c.unique_ip_k_assim for c in itog_mas0])
#
# plt.axis([0, len(NUM0) + len(NUM1), -0.00005, 0.00005])
# plt.xlabel('Отсчет')
# plt.ylabel('ss')
# plt.title('Ассиметрия')
# plt.minorticks_on()
# plt.grid()
# plt.show()
# # #
# #эксцесс
# # print(k_ek_ln)
# plt.subplot(111)
# plt.bar(NUM1, [c.unique_ip_k_eks for c in itog_mas1], color='r')
# plt.bar(NUM0, [c.unique_ip_k_eks for c in itog_mas0])
#
# # plt.bar(fff(a1, a2, mean_length)[13], fff(a1, a2, mean_length)[9], color='r')
# plt.xlabel('Отсчет')
# plt.ylabel('ss')
# plt.title('Эксцесса')
# plt.minorticks_on()
# plt.grid()
# plt.show()
# #
# # #контрэксцесс
# # #
# plt.subplot(111)
# plt.bar(NUM1, [c.unique_ip_kontr for c in itog_mas1], color='r')
# plt.bar(NUM0, [c.unique_ip_kontr for c in itog_mas0])
#
# # plt.bar(fff(a1, a2, mean_length)[13], fff(a1, a2, mean_length)[10], color='r')
# plt.xlabel('Отсчет')
# plt.ylabel('ss')
# plt.title('Контр Эксцесс')
# plt.minorticks_on()
# plt.grid()
# plt.show()
# # #
# # #энтропийный коэф
# # #
# plt.subplot(111)
# plt.bar(NUM1, [c.unique_ip_en_k for c in itog_mas1], color='r')
# plt.bar(NUM0, [c.unique_ip_en_k for c in itog_mas0])
#
# # plt.bar(fff(a1, a2, mean_length)[13], fff(a1, a2, mean_length)[11], color='r')
# # plt.axis([0, len(range(len(k))), 0, 0.8])
# plt.xlabel('Отсчет')
# plt.ylabel('ss')
# plt.title('Энтропийный коэф')
# plt.minorticks_on()
# plt.grid()
# plt.show()
# # #
# # #энтр коэф \ контр
# # #
# plt.subplot(111)
# plt.title('entr_k / kontr')
# plt.plot([c.unique_ip_en_k for c in itog_mas1], [c.unique_ip_kontr for c in itog_mas1] , 'r^')
# plt.plot([c.unique_ip_en_k for c in itog_mas0], [c.unique_ip_kontr for c in itog_mas0] , 'b*')
#
# # plt.plot(fff(a1, a2, mean_length)[11], fff(a1, a2, mean_length)[10], 'r^')
# plt.xlabel('entr_K')
# plt.ylabel('kontr')
# plt.show()
# # #
# # #ассим \ экс
# # #
# plt.subplot(111)
# plt.title('k_assim*2 / k_eks')
# plt.plot( [c.unique_ip_k_assim**2 for c in itog_mas1], [c.unique_ip_k_eks for c in itog_mas1], 'r^')
# plt.plot( [c.unique_ip_k_assim**2 for c in itog_mas0], [c.unique_ip_k_eks for c in itog_mas0], 'b*')
#
# # plt.plot([k**2 for k in fff(a1, a2, mean_length)[8]], fff(a1, a2, mean_length)[9], 'r^')
# plt.xlabel('k_assim**2')
# plt.ylabel('k_eks')
# plt.show()
# # #
# # #kont/entr
# # #
#
# plt.subplot(111)
# plt.title('kontr / entr_k')
# plt.xlabel('kontr')
# plt.ylabel('entr_k')
# plt.plot([c.unique_ip_kontr for c in itog_mas1], [c.unique_ip_en_k for c in itog_mas1] , 'r^')
# plt.plot([c.unique_ip_kontr for c in itog_mas0], [c.unique_ip_en_k for c in itog_mas0] , 'b*')
#
# # plt.plot(fff(a1, a2, mean_length)[10], fff(a1, a2, mean_length)[11], 'r^')
# plt.show()
# # #
# import plotly.graph_objs as go
# import plotly
# fig1 = go.Scatter3d(x=[c.unique_ip_en_k for c in itog_mas0], y=[c.unique_ip_k_assim for c in itog_mas0],                    z=[c.unique_ip_kontr for c in itog_mas0],                    marker=dict(opacity=0.9, reversescale=True,size=5),                    line=dict(width=0.2), mode='markers')
# fig2 = go.Scatter3d(x=[c.unique_ip_en_k for c in itog_mas1], y=[c.unique_ip_k_assim for c in itog_mas1],                    z=[c.unique_ip_kontr for c in itog_mas1],                    marker=dict(opacity=0.9, reversescale=True,size=5),                    line=dict(width=0.2), mode='markers')
# mylayout = go.Layout(scene=dict(xaxis=dict( title="entr_k"),
#                                 yaxis=dict( title="k_assim"),
#                                 zaxis=dict(title="kontr")),)
#
# #Plot and save html
# plotly.offline.plot({"data": [fig1, fig2],
#                      "layout": mylayout},
#                      auto_open=True,
#                      filename=("3DPlot.html"))
#
#
# # In[115]:
#
#
# print ('ГРАФИКИ ДЛЯ УНИКАЛЬНЫХ ПОРТОВ АЙПИ ПАКЕТА')
#
#
# #ассиметрия
# plt.subplot(111)
# plt.bar(NUM1, [c.unique_port_k_assim for c in itog_mas1], color='r')
# plt.bar(NUM0, [c.unique_port_k_assim for c in itog_mas0])
#
# plt.axis([0, len(NUM0) + len(NUM1), -0.00005, 0.00005])
# plt.xlabel('Отсчет')
# plt.ylabel('ss')
# plt.title('Ассиметрия')
# plt.minorticks_on()
# plt.grid()
# plt.show()
# # #
# #эксцесс
# # print(k_ek_ln)
# plt.subplot(111)
# plt.bar(NUM1, [c.unique_port_k_eks for c in itog_mas1], color='r')
# plt.bar(NUM0, [c.unique_port_k_eks for c in itog_mas0])
#
# # plt.bar(fff(a1, a2, mean_length)[13], fff(a1, a2, mean_length)[9], color='r')
# plt.xlabel('Отсчет')
# plt.ylabel('ss')
# plt.title('Эксцесса')
# plt.minorticks_on()
# plt.grid()
# plt.show()
# #
# # #контрэксцесс
# # #
# plt.subplot(111)
# plt.bar(NUM1, [c.unique_port_kontr for c in itog_mas1], color='r')
# plt.bar(NUM0, [c.unique_port_kontr for c in itog_mas0])
#
# # plt.bar(fff(a1, a2, mean_length)[13], fff(a1, a2, mean_length)[10], color='r')
# plt.xlabel('Отсчет')
# plt.ylabel('ss')
# plt.title('Контр Эксцесс')
# plt.minorticks_on()
# plt.grid()
# plt.show()
# # #
# # #энтропийный коэф
# # #
# plt.subplot(111)
# plt.bar(NUM1, [c.unique_port_en_k for c in itog_mas1], color='r')
# plt.bar(NUM0, [c.unique_port_en_k for c in itog_mas0])
#
# # plt.bar(fff(a1, a2, mean_length)[13], fff(a1, a2, mean_length)[11], color='r')
# # plt.axis([0, len(range(len(k))), 0, 0.8])
# plt.xlabel('Отсчет')
# plt.ylabel('ss')
# plt.title('Энтропийный коэф')
# plt.minorticks_on()
# plt.grid()
# plt.show()
# # #
# # #энтр коэф \ контр
# # #
# plt.subplot(111)
# plt.title('entr_k / kontr')
# plt.plot([c.unique_port_en_k for c in itog_mas1], [c.unique_port_kontr for c in itog_mas1] , 'r^')
# plt.plot([c.unique_port_en_k for c in itog_mas0], [c.unique_port_kontr for c in itog_mas0] , 'b*')
#
# # plt.plot(fff(a1, a2, mean_length)[11], fff(a1, a2, mean_length)[10], 'r^')
# plt.xlabel('entr_K')
# plt.ylabel('kontr')
# plt.show()
# # #
# # #ассим \ экс
# # #
# plt.subplot(111)
# plt.title('k_assim*2 / k_eks')
# plt.plot( [c.unique_port_k_assim**2 for c in itog_mas1], [c.unique_port_k_eks for c in itog_mas1], 'r^')
# plt.plot( [c.unique_port_k_assim**2 for c in itog_mas0], [c.unique_port_k_eks for c in itog_mas0], 'b*')
#
# # plt.plot([k**2 for k in fff(a1, a2, mean_length)[8]], fff(a1, a2, mean_length)[9], 'r^')
# plt.xlabel('k_assim**2')
# plt.ylabel('k_eks')
# plt.show()
# # #
# # #kont/entr
# # #
#
# plt.subplot(111)
# plt.title('kontr / entr_k')
# plt.xlabel('kontr')
# plt.ylabel('entr_k')
# plt.plot([c.unique_port_kontr for c in itog_mas1], [c.unique_port_en_k for c in itog_mas1] , 'r^')
# plt.plot([c.unique_port_kontr for c in itog_mas0], [c.unique_port_en_k for c in itog_mas0] , 'b*')
#
# # plt.plot(fff(a1, a2, mean_length)[10], fff(a1, a2, mean_length)[11], 'r^')
# plt.show()
# # #
# import plotly.graph_objs as go
# import plotly
# fig1 = go.Scatter3d(x=[c.unique_port_en_k for c in itog_mas0], y=[c.unique_port_k_assim for c in itog_mas0],                    z=[c.unique_port_kontr for c in itog_mas0],                    marker=dict(opacity=0.9, reversescale=True,size=5),                    line=dict(width=0.2), mode='markers')
# fig2 = go.Scatter3d(x=[c.unique_port_en_k for c in itog_mas1], y=[c.unique_port_k_assim for c in itog_mas1],                    z=[c.unique_port_kontr for c in itog_mas1],                    marker=dict(opacity=0.9, reversescale=True,size=5),                    line=dict(width=0.2), mode='markers')
# mylayout = go.Layout(scene=dict(xaxis=dict( title="entr_k"),
#                                 yaxis=dict( title="k_assim"),
#                                 zaxis=dict(title="kontr")),)
#
# #Plot and save html
# plotly.offline.plot({"data": [fig1, fig2],
#                      "layout": mylayout},
#                      auto_open=True,
#                      filename=("3DPlot.html"))
#
#
# # In[116]:
#
#
# print ('ГРАФИКИ ДЛЯ ИНТЕНСИВНОСТИ ПАКЕТ')
#
# #ассиметрия
# plt.subplot(111)
# plt.bar(NUM1, [c.intens_p_k_assim for c in itog_mas1], color='r')
# plt.bar(NUM0, [c.intens_p_k_assim for c in itog_mas0])
#
# plt.axis([0, len(NUM0) + len(NUM1), -0.00005, 0.00005])
# plt.xlabel('Отсчет')
# plt.ylabel('ss')
# plt.title('Ассиметрия')
# plt.minorticks_on()
# plt.grid()
# plt.show()
# # #
# #эксцесс
# # print(k_ek_ln)
# plt.subplot(111)
# plt.bar(NUM1, [c.intens_p_k_eks for c in itog_mas1], color='r')
# plt.bar(NUM0, [c.intens_p_k_eks for c in itog_mas0])
#
# # plt.bar(fff(a1, a2, mean_length)[13], fff(a1, a2, mean_length)[9], color='r')
# plt.xlabel('Отсчет')
# plt.ylabel('ss')
# plt.title('Эксцесса')
# plt.minorticks_on()
# plt.grid()
# plt.show()
# #
# # #контрэксцесс
# # #
# plt.subplot(111)
# plt.bar(NUM1, [c.intens_p_kontr for c in itog_mas1], color='r')
# plt.bar(NUM0, [c.intens_p_kontr for c in itog_mas0])
#
# # plt.bar(fff(a1, a2, mean_length)[13], fff(a1, a2, mean_length)[10], color='r')
# plt.xlabel('Отсчет')
# plt.ylabel('ss')
# plt.title('Контр Эксцесс')
# plt.minorticks_on()
# plt.grid()
# plt.show()
# # #
# # #энтропийный коэф
# # #
# plt.subplot(111)
# plt.bar(NUM1, [c.intens_p_en_k for c in itog_mas1], color='r')
# plt.bar(NUM0, [c.intens_p_en_k for c in itog_mas0])
#
# # plt.bar(fff(a1, a2, mean_length)[13], fff(a1, a2, mean_length)[11], color='r')
# # plt.axis([0, len(range(len(k))), 0, 0.8])
# plt.xlabel('Отсчет')
# plt.ylabel('ss')
# plt.title('Энтропийный коэф')
# plt.minorticks_on()
# plt.grid()
# plt.show()
# # #
# # #энтр коэф \ контр
# # #
# plt.subplot(111)
# plt.title('entr_k / kontr')
# plt.plot([c.intens_p_en_k for c in itog_mas1], [c.intens_p_kontr for c in itog_mas1] , 'r^')
# plt.plot([c.intens_p_en_k for c in itog_mas0], [c.intens_p_kontr for c in itog_mas0] , 'b*')
#
# # plt.plot(fff(a1, a2, mean_length)[11], fff(a1, a2, mean_length)[10], 'r^')
# plt.xlabel('entr_K')
# plt.ylabel('kontr')
# plt.show()
# # #
# # #ассим \ экс
# # #
# plt.subplot(111)
# plt.title('k_assim*2 / k_eks')
# plt.plot( [c.intens_p_k_assim**2 for c in itog_mas1], [c.intens_p_k_eks for c in itog_mas1], 'r^')
# plt.plot( [c.intens_p_k_assim**2 for c in itog_mas0], [c.intens_p_k_eks for c in itog_mas0], 'b*')
#
# # plt.plot([k**2 for k in fff(a1, a2, mean_length)[8]], fff(a1, a2, mean_length)[9], 'r^')
# plt.xlabel('k_assim**2')
# plt.ylabel('k_eks')
# plt.show()
# # #
# # #kont/entr
# # #
#
# plt.subplot(111)
# plt.title('kontr / entr_k')
# plt.xlabel('kontr')
# plt.ylabel('entr_k')
# plt.plot([c.intens_p_kontr for c in itog_mas1], [c.intens_p_en_k for c in itog_mas1] , 'r^')
# plt.plot([c.intens_p_kontr for c in itog_mas0], [c.intens_p_en_k for c in itog_mas0] , 'b*')
#
# # plt.plot(fff(a1, a2, mean_length)[10], fff(a1, a2, mean_length)[11], 'r^')
# plt.show()
# # #
# import plotly.graph_objs as go
# import plotly
# fig1 = go.Scatter3d(x=[c.intens_p_en_k for c in itog_mas0], y=[c.intens_p_k_assim for c in itog_mas0],                    z=[c.intens_p_kontr for c in itog_mas0],                    marker=dict(opacity=0.9, reversescale=True,size=5),                    line=dict(width=0.2), mode='markers')
# fig2 = go.Scatter3d(x=[c.intens_p_en_k for c in itog_mas1], y=[c.intens_p_k_assim for c in itog_mas1],                    z=[c.intens_p_kontr for c in itog_mas1],                    marker=dict(opacity=0.9, reversescale=True,size=5),                    line=dict(width=0.2), mode='markers')
# mylayout = go.Layout(scene=dict(xaxis=dict( title="entr_k"),
#                                 yaxis=dict( title="k_assim"),
#                                 zaxis=dict(title="kontr")),)
#
# #Plot and save html
# plotly.offline.plot({"data": [fig1, fig2],
#                      "layout": mylayout},
#                      auto_open=True,
#                      filename=("3DPlot.html"))
#
#
#
#
# # In[117]:
#
#
# print ('ГРАФИКИ ДЛЯ ИНТЕНСИВНОСТИ БИТ')
#
# #ассиметрия
# plt.subplot(111)
# plt.bar(NUM1, [c.intens_bit_k_assim for c in itog_mas1], color='r')
# plt.bar(NUM0, [c.intens_bit_k_assim for c in itog_mas0])
#
# plt.axis([0, len(NUM0) + len(NUM1), -0.00005, 0.00005])
# plt.xlabel('Отсчет')
# plt.ylabel('ss')
# plt.title('Ассиметрия')
# plt.minorticks_on()
# plt.grid()
# plt.show()
# # #
# #эксцесс
# # print(k_ek_ln)
# plt.subplot(111)
# plt.bar(NUM1, [c.intens_bit_k_eks for c in itog_mas1], color='r')
# plt.bar(NUM0, [c.intens_bit_k_eks for c in itog_mas0])
#
# # plt.bar(fff(a1, a2, mean_length)[13], fff(a1, a2, mean_length)[9], color='r')
# plt.xlabel('Отсчет')
# plt.ylabel('ss')
# plt.title('Эксцесса')
# plt.minorticks_on()
# plt.grid()
# plt.show()
# #
# # #контрэксцесс
# # #
# plt.subplot(111)
# plt.bar(NUM1, [c.intens_bit_kontr for c in itog_mas1], color='r')
# plt.bar(NUM0, [c.intens_bit_kontr for c in itog_mas0])
#
# # plt.bar(fff(a1, a2, mean_length)[13], fff(a1, a2, mean_length)[10], color='r')
# plt.xlabel('Отсчет')
# plt.ylabel('ss')
# plt.title('Контр Эксцесс')
# plt.minorticks_on()
# plt.grid()
# plt.show()
# # #
# # #энтропийный коэф
# # #
# plt.subplot(111)
# plt.bar(NUM1, [c.intens_bit_en_k for c in itog_mas1], color='r')
# plt.bar(NUM0, [c.intens_bit_en_k for c in itog_mas0])
#
# # plt.bar(fff(a1, a2, mean_length)[13], fff(a1, a2, mean_length)[11], color='r')
# # plt.axis([0, len(range(len(k))), 0, 0.8])
# plt.xlabel('Отсчет')
# plt.ylabel('ss')
# plt.title('Энтропийный коэф')
# plt.minorticks_on()
# plt.grid()
# plt.show()
# # #
# # #энтр коэф \ контр
# # #
# plt.subplot(111)
# plt.title('entr_k / kontr')
# plt.plot([c.intens_bit_en_k for c in itog_mas1], [c.intens_bit_kontr for c in itog_mas1] , 'r^')
# plt.plot([c.intens_bit_en_k for c in itog_mas0], [c.intens_bit_kontr for c in itog_mas0] , 'b*')
#
# # plt.plot(fff(a1, a2, mean_length)[11], fff(a1, a2, mean_length)[10], 'r^')
# plt.xlabel('entr_K')
# plt.ylabel('kontr')
# plt.show()
# # #
# # #ассим \ экс
# # #
# plt.subplot(111)
# plt.title('k_assim*2 / k_eks')
# plt.plot( [c.intens_bit_k_assim**2 for c in itog_mas1], [c.intens_bit_k_eks for c in itog_mas1], 'r^')
# plt.plot( [c.intens_bit_k_assim**2 for c in itog_mas0], [c.intens_bit_k_eks for c in itog_mas0], 'b*')
#
# # plt.plot([k**2 for k in fff(a1, a2, mean_length)[8]], fff(a1, a2, mean_length)[9], 'r^')
# plt.xlabel('k_assim**2')
# plt.ylabel('k_eks')
# plt.show()
# # #
# # #kont/entr
# # #
#
# plt.subplot(111)
# plt.title('kontr / entr_k')
# plt.xlabel('kontr')
# plt.ylabel('entr_k')
# plt.plot([c.intens_bit_kontr for c in itog_mas1], [c.intens_bit_en_k for c in itog_mas1] , 'r^')
# plt.plot([c.intens_bit_kontr for c in itog_mas0], [c.intens_bit_en_k for c in itog_mas0] , 'b*')
#
# # plt.plot(fff(a1, a2, mean_length)[10], fff(a1, a2, mean_length)[11], 'r^')
# plt.show()
# # #
# import plotly.graph_objs as go
# import plotly
# fig1 = go.Scatter3d(x=[c.intens_bit_en_k for c in itog_mas0], y=[c.intens_bit_k_assim for c in itog_mas0],                    z=[c.intens_bit_kontr for c in itog_mas0],                    marker=dict(opacity=0.9, reversescale=True,size=5),                    line=dict(width=0.2), mode='markers')
# fig2 = go.Scatter3d(x=[c.intens_bit_en_k for c in itog_mas1], y=[c.intens_bit_k_assim for c in itog_mas1],                    z=[c.intens_bit_kontr for c in itog_mas1],                    marker=dict(opacity=0.9, reversescale=True,size=5),                    line=dict(width=0.2), mode='markers')
# mylayout = go.Layout(scene=dict(xaxis=dict( title="entr_k"),
#                                 yaxis=dict( title="k_assim"),
#                                 zaxis=dict(title="kontr")),)
#
# #Plot and save html
# plotly.offline.plot({"data": [fig1, fig2],
#                      "layout": mylayout},
#                      auto_open=True,
#                      filename=("3DPlot.html"))
#


