import pandas as pd
import numpy as np
from sklearn import svm, datasets
from sklearn.datasets import load_iris, make_blobs
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import recall_score, accuracy_score, precision_score
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.preprocessing import PolynomialFeatures

# from sss import SVM1
def OSVM(label1, label2):
    ris = pd.read_csv('./csv/last.csv', delimiter=',')
    new = pd.DataFrame(ris[label1], columns=[label1])
    new[label2] = ris[label2]



    # X = ris.drop('classif', axis='columns')
    X = new
    y = ris['classif']
    X = X.to_numpy()
    y = y.to_numpy()
    print(X)

    pca = PCA(n_components=2)
    X = pca.fit_transform(X)

    # plt.scatter(X[:, 1], X[:, 0], c=y, cmap='winter')
    # plt.show()

    x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    h = (x_max / x_min)/100
    xx, yy = np.meshgrid(np.arange(x_min, x_max, abs(h)), np.arange(y_min, y_max, abs(h)))
    X_plot = np.c_[xx.ravel(), yy.ravel()]
    print(X_plot)


    # y = (y == 1).astype(int)
    # X_train, X_test, y_train, Y_test = train_test_split(X, y, test_size=0.8, random_state=2020)
    # print(X)
    # print(y)
    #
    X_train, X_test, Y_train, Y_test = train_test_split(X, y, test_size=0.8, random_state=2020)

    C = 244
    # # plt.show()
    svc_classifier = svm.SVC(kernel='linear', C = C).fit(X, y)
    Z = svc_classifier.predict(X_plot)
    Z = Z.reshape(xx.shape)
    plt.figure(figsize=(15, 5))
    plt.subplot(121)
    plt.contourf(xx, yy, Z, cmap=plt.cm.tab10, alpha=0.3)
    plt.scatter(X[:, 0], X[:, 1], c=y, cmap=plt.cm.Set1)
    plt.xlabel('Sepal length')
    plt.ylabel('Sepal width')
    plt.xlim(xx.min(), xx.max())
    plt.title('Support Vector Classifier with linear kernel')
    plt.show()
    # #
    #


    poly = PolynomialFeatures(degree=13)
    X_poly = poly.fit_transform(X)

    C = 234
    logit = LogisticRegression(C=C, n_jobs=-1, random_state=100, max_iter=len(X))
    logit.fit(X_poly, y)

    def plot_boundary(clf, X, y, grid_step=.01, poly_featurizer=None):
        x_min, x_max = X[:, 0].min() - .1, X[:, 0].max() + .1
        y_min, y_max = X[:, 1].min() - .1, X[:, 1].max() + .1
        xx, yy = np.meshgrid(np.arange(x_min, x_max, grid_step),
        np.arange(y_min, y_max, grid_step))

        # каждой точке в сетке [x_min, m_max]x[y_min, y_max]
        # ставим в соответствие свой цвет
        Z = clf.predict(poly_featurizer.transform(np.c_[xx.ravel(), yy.ravel()]))
        Z = Z.reshape(xx.shape)
        plt.contour(xx, yy, Z, cmap=plt.cm.Paired)

    plot_boundary(logit, X, y, grid_step=.01, poly_featurizer=poly)

    plt.scatter(X[y == 1, 0], X[y == 1, 1], c='red', label='NOT OK')
    plt.scatter(X[y == 0, 0], X[y == 0, 1], c='green', label='OK')
    plt.xlabel("en_k")
    plt.ylabel("kontr")
    plt.title('linear')
    plt.legend()
    plt.show()

    print("Доля правильных ответов классификатора на обучающей выборке:",
    round(logit.score(X_poly, y), 2))
    # y_predict = svc_classifier.predict(X_test)
    # print(recall_score(Y_test, y_predict, average=None))

    # skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=17)
    #
    # c_values = np.logspace(-2, 3, 500)
    #
    # logit_searcher = LogisticRegressionCV(Cs=c_values, cv=skf, verbose=1, n_jobs=-1)
    # logit_searcher.fit(X_poly, y)
    # print(logit_searcher.C_[0])

def OSVM1():
    ris = pd.read_csv('./csv/last.csv', delimiter=',')
    # new = pd.DataFrame(ris[label1], columns=[label1])
    # new[label2] = ris[label2]



    X = ris.drop('classif', axis='columns')
    # X = new
    y = ris['classif']
    X = X.to_numpy()
    y = y.to_numpy()
    print(X)
    pca = PCA(n_components=2)
    X = pca.fit_transform(X)

    # plt.scatter(X[:, 1], X[:, 0], c=y, cmap='winter')
    # plt.show()

    x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    h = (x_max / x_min)/100
    xx, yy = np.meshgrid(np.arange(x_min, x_max, abs(h)), np.arange(y_min, y_max, abs(h)))
    X_plot = np.c_[xx.ravel(), yy.ravel()]
    # print(X_plot)
    #

    # y = (y == 1).astype(int)
    # X_train, X_test, y_train, Y_test = train_test_split(X, y, test_size=0.8, random_state=2020)
    # print(X)
    # print(y)
    #
    X_train, X_test, Y_train, Y_test = train_test_split(X, y, test_size=0.4, random_state=2020)

    C = 234
    # # # plt.show()
    svc_classifier = svm.SVC(kernel='rbf', C = C).fit(X, y)
    Z = svc_classifier.predict(X_plot)
    Z = Z.reshape(xx.shape)
    plt.figure(figsize=(15, 5))
    plt.subplot(121)
    plt.contourf(xx, yy, Z, cmap=plt.cm.tab10, alpha=0.3)
    plt.scatter(X[:, 0], X[:, 1], c=y, cmap=plt.cm.Set1)
    plt.xlabel('Sepal length')
    plt.ylabel('Sepal width')
    plt.xlim(xx.min(), xx.max())
    plt.title('Support Vector Classifier with linear kernel')
    plt.show()
    # #
    #

    poly = PolynomialFeatures(degree=13)
    X_poly = poly.fit_transform(X)

    C = 234
    logit = LogisticRegression(solver='lbfgs',C=C, penalty='l2', random_state=100)
    logit.fit(X_poly, y)

    # def plot_boundary(clf, X, y, grid_step=.01, poly_featurizer=None):
    #     x_min, x_max = X[:, 0].min() - .1, X[:, 0].max() + .1
    #     y_min, y_max = X[:, 1].min() - .1, X[:, 1].max() + .1
    #     xx, yy = np.meshgrid(np.arange(x_min, x_max, grid_step),
    #     np.arange(y_min, y_max, grid_step))
    #
    #     # каждой точке в сетке [x_min, m_max]x[y_min, y_max]
    #     # ставим в соответствие свой цвет
    #     Z = clf.predict(poly_featurizer.transform(np.c_[xx.ravel(), yy.ravel()]))
    #     Z = Z.reshape(xx.shape)
    #     plt.contour(xx, yy, Z, cmap=plt.cm.Paired)
    #
    # # plot_boundary(logit, X, y, grid_step=.01, poly_featurizer=poly)
    #
    # plt.scatter(X[y == 1, 0], X[y == 1, 1], c='red', label='NOT OK')
    # plt.scatter(X[y == 0, 0], X[y == 0, 1], c='green', label='OK')
    # plt.xlabel("Тест 1")
    # plt.ylabel("Тест 2")
    # plt.title('PREKOLYAMBA')
    # plt.legend()
    # # plt.show()

    print("Доля правильных ответов классификатора на обучающей выборке:",
    round(logit.score(X_poly, y), 4))
    # y_predict = svc_classifier.predict(X_test)
    # print(recall_score(Y_test, y_predict, average=None))

    # skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=17)
    #
    # c_values = np.logspace(-2, 3, 500)
    #
    # logit_searcher = LogisticRegressionCV(Cs=c_values, cv=skf, verbose=1, n_jobs=-1)
    # logit_searcher.fit(X_poly, y)
    # print(logit_searcher.C_[0])
