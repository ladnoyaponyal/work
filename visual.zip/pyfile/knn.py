import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from sklearn.datasets import load_breast_cancer
from sklearn.metrics import confusion_matrix
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
import seaborn as sns
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score
from sklearn.model_selection import GridSearchCV, cross_val_score


def KNN():
    ris = pd.read_csv('./csv/last.csv', delimiter=',')
    # new = pd.DataFrame(ris[label1], columns=[label1])
    # new[label2] = ris[label2]
    #
    X = ris.drop('classif', axis='columns')
    # X = new
    y = ris['classif']
    X = X.to_numpy()


    y = y.to_numpy()


    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=51555)
    # tree = DecisionTreeClassifier(max_depth=1, random_state=2020)
    knn = KNeighborsClassifier(algorithm='auto', n_neighbors=35, weights='distance', n_jobs=2)

    # tree.fit(X_train, y_train)
    knn.fit(X_train, y_train)
    knn_pried = knn.predict(X_test)

    ac = accuracy_score(y_test, knn_pried)
    pr = precision_score(y_test, knn_pried)
    re = recall_score(y_test, knn_pried)
    return ac, pr, re
