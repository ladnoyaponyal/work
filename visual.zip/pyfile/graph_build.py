import matplotlib.pyplot as plt
import pyqtgraph as pg

def build_graph(df):
    #mean_length
    fig1 = plt.subplot(111)
    fig1 =plt.bar(range(len(df)), df['mean_ln'])

    # plt.bar(Number1, [x.mean_length for x in array_object_on_Interval1], color = 'r')
    # plt.axis([0, len(array_object_on_Interval), 0, 1000])
    fig1 = plt.xlabel('Отсчет')
    fig1 = plt.ylabel('ss')
    fig1 = plt.title('mean_ln')
    fig1 = plt.minorticks_on()

    fig1 = plt.grid()
    fig1 =plt.savefig('./png/mean_length.png')
    fig1 =plt.show()

    #
    # # In[22]:

def built2(df):
    #min_length
    fig2 = plt.subplot(111)
    fig2 = plt.bar(range(len(df)), df['min_ln'])
    # plt.bar(Number1, [x.min_length for x in array_object_on_Interval1], color = 'r')
    # plt.axis([0, len(array_object_on_Interval), 0, 200])
    fig2 = plt.xlabel('Отсчет')
    fig2 = plt.ylabel('ss')
    fig2 = plt.title('min_Length')
    fig2 = plt.minorticks_on()

    fig2 = plt.grid()
    fig2 = plt.show()


    # In[23]:


    #max_length
    fig3 = plt.subplot(111)
    fig3 = plt.bar(range(len(df)), df['max_ln'])
    # plt.bar(Number1, [x.max_length for x in array_object_on_Interval1], color='r')
    # plt.axis([0, len(array_object_on_Interval), 0, 4000])
    fig3 = plt.xlabel('Отсчет')
    fig3 = plt.ylabel('ss')
    fig3 = plt.title('max_Length')
    fig3 = plt.minorticks_on()
    fig3 = plt.grid()
    fig3 = plt.show()

    # # In[24]:
    #
    #
    # #intens -packet
    # plt.subplot(111)
    # plt.bar(Number0, [x.intens for x in array_object_on_Interval0])
    # plt.bar(Number1, [x.intens for x in array_object_on_Interval1], color='r')
    # # plt.bar(NUMBER1, intens1, color='r')
    # # plt.axis([0, len(array_object_on_Interval), 0, 300])
    # plt.xlabel('Отсчет')
    # plt.ylabel('ss')
    # plt.title('intens_packet')
    # plt.minorticks_on()
    # plt.grid()
    # plt.show()
    #
    #
    # # In[25]:
    #
    #
    # #syn_flags
    # plt.subplot(111)
    # plt.bar(Number0, [x.syn for x in array_object_on_Interval0])
    # plt.bar(Number1, [x.syn for x in array_object_on_Interval1], color='r')
    # # plt.bar(NUMBER1, syn1, color= 'r')
    # plt.axis([0, len(array_object_on_Interval), 0, 20])
    # plt.xlabel('Отсчет')
    # plt.ylabel('ss')
    # plt.title('syn_flags')
    # plt.minorticks_on()
    # plt.grid()
    # plt.show()
    #
    #
    # # In[26]:
    #
    #
    # #fin_flags
    # plt.subplot(111)
    # plt.bar(Number0, [x.fin for x in array_object_on_Interval0])
    # plt.bar(Number1, [x.fin for x in array_object_on_Interval1], color='r')
    # # plt.bar(NUMBER1, syn1, color= 'r')
    # plt.axis([0, len(array_object_on_Interval), 0, 30])
    # plt.xlabel('Отсчет')
    # plt.ylabel('ss')
    # plt.title('fin_flags')
    # plt.minorticks_on()
    # plt.grid()
    # plt.show()
    #
    #
    # # In[27]:
    #
    #
    # #ack_flags
    # plt.subplot(111)
    # plt.bar(Number0, [x.ack for x in array_object_on_Interval0])
    # plt.bar(Number1, [x.ack for x in array_object_on_Interval1], color='r')
    # # plt.bar(NUMBER1, syn1, color= 'r')
    # plt.axis([0, len(array_object_on_Interval), 0, 1000])
    # plt.xlabel('Отсчет')
    # plt.ylabel('ss')
    # plt.title('ack_flags')
    # plt.minorticks_on()
    # plt.grid()
    # plt.show()
    #
    #
    # # In[28]:
    #
    #
    # #unique ip-ip
    # plt.subplot(111)
    # plt.bar(Number0, [x.unique_ip for x in array_object_on_Interval0])
    # plt.bar(Number1, [x.unique_ip for x in array_object_on_Interval1], color='r')
    # # plt.bar(NUMBER1, unique1, color='r')
    # plt.xlabel('Отсчет')
    # plt.ylabel('ss')
    # plt.title('unique ip - ip')
    # plt.minorticks_on()
    # plt. axis([0, len(array_object_on_Interval), 0, 50])
    # plt.grid()
    # plt.show()
    #
    #
    # # In[29]:
    #
    #
    # #intens_bit
    # plt.subplot(111)
    # plt.bar(Number0, [x.intens_bit for x in array_object_on_Interval0])
    # plt.bar(Number1, [x.intens_bit for x in array_object_on_Interval1], color='r')
    # # plt.bar(NUMBER1, bit1, color='r')
    # plt.axis([0, len(array_object_on_Interval), 0, 400000])
    # plt.xlabel('Отсчет')
    # plt.ylabel('ss')
    # plt.title('intense_bit')
    # plt.minorticks_on()
    # plt.grid()
    # plt.show()
    #
    #
    # # In[30]:
    #
    #
    # #unique_port
    # plt.subplot(111)
    # plt.bar(Number0, [x.unique_port for x in array_object_on_Interval0])
    # plt.bar(Number1, [x.unique_port for x in array_object_on_Interval1], color='r')
    # # plt.bar(NUMBER1, bit1, color='r')
    # plt.axis([0, len(array_object_on_Interval), 0, 40])
    # plt.xlabel('Отсчет')
    # plt.ylabel('ss')
    # plt.title('unique_port-port')
    # plt.minorticks_on()
    # plt.grid()
    # plt.show()
    #
# def graphs(x, y):
#     pw = pg.plot(x, y, pen='r')  # plot x vs y in red
#     win = pg.GraphicsWindow()
#     win.addPlot(data1, row=0, col=0)
