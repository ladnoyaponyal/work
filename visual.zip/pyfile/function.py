import csv
from typing import List, Any

from pyfile.classes import Packet, Interval, Default
from pyfile.stat_function import koef_assim, kontrecsces, entr_koef, koef_eksces
import numpy as np
import pandas as pd
# from tqdm import tqdm
# import win10toast
import ctypes  # An included library with Python install.
import platform, os


### ?????? CSV ????? ? ????? Packet
def read_from_csv_2_array_object(filename):
    array_object_of_Packet = []
    # len_of_csv = len(open(filename).readlines())
    # filename = 'csv/not_atack.csv'

    with open(filename, encoding="ISO-8859-1") as r_file:
        file_reader = csv.reader(r_file, delimiter=',')
        count = 0
        for row in file_reader:
            if count != 0:
                a = Packet(row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7], row[8], row[9], row[10],
                           row[11], row[12], row[13], row[14], row[15], row[16])
                array_object_of_Packet.append(a)
                #         print(a.length)
                count += 1
                del a
                # if count == int(0.1 * len_of_csv):
                #     print('10%')
                # if count == int(0.2 * len_of_csv):
                #     print('20%')
                # if count == int(0.3 * len_of_csv):
                #     print('30%')
                # if count == int(0.4 * len_of_csv):
                #     print('40%')
                # if count == int(0.5 * len_of_csv):
                #     print('50%')
                # if count == int(0.6 * len_of_csv):
                #     print('60%')
                # if count == int(0.7 * len_of_csv):
                #     print('70%')
                # if count == int(0.8 * len_of_csv):
                #     print('80%')
                # if count == int(0.9 * len_of_csv):
                #     print('90%')
                # if count == len_of_csv:
                #     print('100%')
            else:
                count += 1
    plt = platform.system()
    if plt == "Linux":
        os.system(f'''notify-send "NOTIFY"  "file {filename} download\n
         hav {count} strings"''')
    elif plt == "Windows":
        ctypes.windll.user32.MessageBoxW(0, f'{filename} ???????? {count} ???????\n'
                                            f'??? ?????? ????????? ? ?????? ???????? ?????? array_object_of_packet',
                                         "Notify", 0)
    # print(f'{filename} ???????? {count} ???????')
    # print(f'??? ?????? ????????? ? ?????? ???????? ?????? array_object_of_packet')
    return array_object_of_Packet


### ??????? ??? ??????? ????????????? ?? ?????????
### ????(???.??, ??.??, ??????, ???)

def func(left_k, right_k, array, counter):
    i = 0
    ln = []
    bit = []
    syn = []
    ack = []
    fin = []
    ip_src = []
    ip_dst = []
    src_port = []
    dst_port = []
    unique_ip = []
    unique_port = []
    l = 0
    classifica = []
    for i in range(counter, len(array)):
        num = array[i].time_relative
        if left_k <= float(num) <= right_k:
            ln.append(int(array[i].length))
            bit.append(int(array[i].length) * 8)
            if int(array[i].syn) == 1:
                syn.append(1)
            else:
                syn.append(0)
            if int(array[i].fin) == 1:
                fin.append(1)
            else:
                fin.append(0)
            if int(array[i].ack) == 1:
                ack.append(1)
            else:
                ack.append(0)
            #             if int(array[i].clas) == 1:
            #                 l += 1
            classifica.append(int(array[i].clas))
            ip_src.append(array[i].ip_src)
            ip_dst.append(array[i].ip_dst)
            src_port.append(array[i].src_port)
            dst_port.append(array[i].dst_port)
            unique_ip.append('src: ' + array[i].src_port + ' dst: ' + array[i].ip_dst)
            unique_port.append('src: ' + array[i].dst_port + ' dst: ' + array[i].ip_dst)
        if right_k < float(array[i].time_relative):
            break
    if len(classifica) == sum(classifica):
        itog = 1
    else:
        itog = 0
    classifica.clear()
    return ln, i, syn, ack, fin, ip_src, ip_dst, src_port, dst_port, len(set(unique_ip)), sum(bit), itog, len(
        set(unique_port))


### ??????? ??? ???????? ???? ?? ??????? ARRAY_OBJECT_OF_PACKET
def wind_on_array_packet(k, step, array_object_of_Packet):
    array_object_on_Interval = []
    NUMBER = []
    num = 0
    # k = float(input('??????? ???????? -????- ?????????? '))
    # step = float(input('??????? ??? ??? ???????? ???? '))
    k1 = 0
    k2 = k
    cnt = 0
    c = float(array_object_of_Packet[-1].time_relative)
    # print(c)

    print('Loading:')
    while k1 <= c:
        if 0 <= k1 <= int(0.1 * c):
            print(1 * '1' + 9 * '0')
        elif int(0.1 * c) < k1 <= int(0.2 * c):
            print(2 * '1' + 8 * '0')
        elif int(0.2 * c) < k1 <= int(0.3 * c):
            print(3 * '1' + 7 * '0')
        elif int(0.3 * c) < k1 <= int(0.4 * c):
            print(4 * '1' + 6 * '0')
        elif int(0.4 * c) < k1 <= int(0.5 * c):
            print(5 * '1' + 5 * '0')
        elif int(0.5 * c) < k1 <= int(0.6 * c):
            print(6 * '1' + 4 * '0')
        elif int(0.6 * c) < k1 <= int(0.7 * c):
            print(7 * '1' + 3 * '0')
        elif int(0.7 * c) < k1 <= int(0.8 * c):
            print(8 * '1' + 2 * '0')
        elif int(0.8 * c) < k1 <= int(0.9 * c):
            print(9 * '1' + 1 * '0')
        else:
            print(9 * '1' + 1 * '0')

        if len(func(k1, k2, array_object_of_Packet, cnt)[0]) != 0:
            b = Interval(func(k1, k2, array_object_of_Packet, cnt)[0],
                         np.mean(func(k1, k2, array_object_of_Packet, cnt)[0]),
                         min(func(k1, k2, array_object_of_Packet, cnt)[0]),
                         max(func(k1, k2, array_object_of_Packet, cnt)[0]),
                         len(func(k1, k2, array_object_of_Packet, cnt)[0]),
                         sum(func(k1, k2, array_object_of_Packet, cnt)[2]),
                         sum(func(k1, k2, array_object_of_Packet, cnt)[3]),
                         sum(func(k1, k2, array_object_of_Packet, cnt)[4]),
                         func(k1, k2, array_object_of_Packet, cnt)[9], func(k1, k2, array_object_of_Packet, cnt)[10],
                         func(k1, k2, array_object_of_Packet, cnt)[5], func(k1, k2, array_object_of_Packet, cnt)[6],
                         func(k1, k2, array_object_of_Packet, cnt)[7], func(k1, k2, array_object_of_Packet, cnt)[8],
                         func(k1, k2, array_object_of_Packet, cnt)[11], func(k1, k2, array_object_of_Packet, cnt)[12])

            array_object_on_Interval.append(b)
            NUMBER.append(num)
            del b
        else:
            #         if func(k1, k2, array_object_of_Packet, cnt)[11] != 1:
            #             b = Interval(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)
            #         else:
            # b = Interval(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
            pass
            # array_object_on_Interval.append(b)
            # NUMBER.append(num)
        cnt = func(k1, k2, array_object_of_Packet, cnt)[1]
        k1, k2 = k1 + step, k2 + step
        num += 1

    plt = platform.system()
    if plt == "Linux":
        os.system(f''' notify-send "NOTIFY" "Data -array_object_of_Packet- downloaded with\n
                                               Window agregation = {k} and step = {step}"''')
    elif plt == "Windows":
        ctypes.windll.user32.MessageBoxW(0, "Data -array_object_of_Packet- downloaded with\n"
                                            f'Window agregation = {k} and step = {step}', "Notify", 0)

    # print(f'Data -array_object_of_Packet- downloaded with')
    # print(f'Window agregation = {k} and step = {step}')
    return array_object_on_Interval


def classification(array):
    global count
    count = 0
    Number0 = []
    Number1 = []
    array_object_on_Interval0: List[Any] = []
    array_object_on_Interval1: List[Any] = []
    for x in array:
        if x.classific == 1:
            array_object_on_Interval1.append(x)
            Number1.append(count)
        else:
            array_object_on_Interval0.append(x)
            Number0.append(count)
        count += 1
    # print(len(array))
    # print(len(array_object_on_Interval0), len(Number0))
    # print(len(array_object_on_Interval1), len(Number1))
    return Number0, Number1, array_object_on_Interval0, array_object_on_Interval1


def interv_2_csv(array_object_on_Interval):
    df = pd.DataFrame([[p.mean_length, p.min_length, p.max_length, p.intens, \
                        p.intens_bit, p.unique_ip, p.unique_port, p.syn, p.fin, \
                        p.ack, p.classification
                        ] for p in array_object_on_Interval],
                      columns=['mean_ln', 'min_ln', 'max_ln', 'intens_p', 'intens_bit', \
                               'unique_ip', 'unique_port', 'syn', 'fin', 'ack', 'classif'])

    # for p in array_object_on_Interval:
    #     d = pd.DataFrame(p.mean_length, p.min_length, p.max_length, p.intens, p.intens_bit, p.unique_ip, p.unique_port, p.syn, p.fin, p.ack, p.classification)
    #     df = pd.concat([df, d])
    #
    # d = pd.concat()
    # # print(df)
    # dff = pd.concat([df, d])
    # ctypes.windll.user32.MessageBoxW(0, "first_wind.csv is created", "Notify", 0)
    df.to_csv('./csv/first_wind.csv', sep=',', encoding='utf-8', index=False)
    # print('first_wind.csv is created')
    return df


def func2(k1, k2, array):
    obj = Default(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    del obj
    f_mean_length = []
    f_min_len = []
    f_max_len = []
    f_intens_bit = []
    f_intens_p = []
    f_unique_ip = []
    f_unique_port = []
    f_class = []
    itog_cl = []
    for i in range(len(array)):
        if int(k1) <= int(i) <= int(k2):
            f_mean_length.append(array[i].mean_length)
            f_min_len.append(array[i].min_length)
            f_max_len.append(array[i].max_length)
            f_intens_bit.append(array[i].intens_bit)
            f_intens_p.append(array[i].intens)
            f_unique_ip.append(array[i].unique_ip)
            f_unique_port.append(array[i].unique_port)
            f_class.append(array[i].classification)
    if len(f_mean_length) > 0:
        if len(f_class) == sum(f_class):
            itog_cl = 1
        else:
            itog_cl = 0
        obj = Default(koef_assim(f_mean_length), koef_eksces(f_mean_length), kontrecsces(f_mean_length),
                      entr_koef(k2 - k1, len(f_mean_length), len(f_mean_length), np.std(f_mean_length)),
                      koef_assim(f_min_len), koef_eksces(f_min_len), kontrecsces(f_min_len),
                      entr_koef(k2 - k1, len(f_min_len), len(f_min_len), np.std(f_min_len)), koef_assim(f_max_len),
                      koef_eksces(f_max_len), kontrecsces(f_max_len),
                      entr_koef(k2 - k1, len(f_max_len), len(f_max_len), np.std(f_max_len)), koef_assim(f_intens_bit),
                      koef_eksces(f_intens_bit), kontrecsces(f_intens_bit),
                      entr_koef(k2 - k1, len(f_intens_bit), len(f_intens_bit), np.std(f_intens_bit)),
                      koef_assim(f_intens_p), koef_eksces(f_intens_p), kontrecsces(f_intens_p),
                      entr_koef(k2 - k1, len(f_intens_p), len(f_intens_p), np.std(f_intens_p)), koef_assim(f_unique_ip),
                      koef_eksces(f_unique_ip), kontrecsces(f_unique_ip),
                      entr_koef(k2 - k1, len(f_unique_ip), len(f_unique_ip), np.std(f_unique_ip)),
                      koef_assim(f_unique_port), koef_eksces(f_unique_port), kontrecsces(f_unique_port),
                      entr_koef(k2 - k1, len(f_unique_port), len(f_unique_port), np.std(f_unique_port)), itog_cl)

    else:
        pass
        # obj = Default(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    f_mean_length.clear()
    f_min_len.clear()
    f_max_len.clear()
    f_intens_bit.clear()
    f_intens_p.clear()
    f_unique_ip.clear()
    f_unique_port.clear()
    f_class.clear()
    return obj


def fff(a1, a2, arr, step2):
    ITOG_MAS = []
    c = len(arr)
    while a2 <= len(arr):
        if 0 <= a2 <= int(0.1 * c):
            print(1 * '1' + 9 * '0')
        elif int(0.1 * c) < a2 <= int(0.2 * c):
            print(2 * '1' + 8 * '0')
        elif int(0.2 * c) < a2 <= int(0.3 * c):
            print(3 * '1' + 7 * '0')
        elif int(0.3 * c) < a2 <= int(0.4 * c):
            print(4 * '1' + 6 * '0')
        elif int(0.4 * c) < a2 <= int(0.5 * c):
            print(5 * '1' + 5 * '0')
        elif int(0.5 * c) < a2 <= int(0.6 * c):
            print(6 * '1' + 4 * '0')
        elif int(0.6 * c) < a2 <= int(0.7 * c):
            print(7 * '1' + 3 * '0')
        elif int(0.7 * c) < a2 <= int(0.8 * c):
            print(8 * '1' + 2 * '0')
        elif int(0.8 * c) < a2 <= int(0.9 * c):
            print(9 * '1' + 1 * '0')
        else:
            print(9 * '1' + 1 * '0')
        #         print(a2)
        ITOG_MAS.append(func2(a1, a2, arr))

        a1, a2 = a1 + step2, a2 + step2

    dff = pd.DataFrame([[p.mean_ln_k_assim, p.mean_ln_k_eks, p.mean_ln_kontr, p.mean_ln_en_k, \
                         p.min_ln_k_assim, p.min_ln_k_eks, p.min_ln_kontr, p.min_ln_en_k, \
                         p.max_ln_k_assim, p.max_ln_k_eks, p.max_ln_kontr, p.max_ln_en_k, \
                         p.intens_p_k_assim, p.intens_p_k_eks, p.intens_p_kontr, p.intens_p_en_k, \
                         p.intens_bit_k_assim, p.intens_bit_k_eks, p.intens_bit_kontr, p.intens_bit_en_k, \
                         p.unique_port_k_assim, p.unique_port_k_eks, p.unique_port_kontr, p.unique_port_en_k, \
                         p.unique_ip_k_assim, p.unique_ip_k_eks, p.unique_ip_kontr, p.unique_ip_en_k, p.classific
                         ] for p in ITOG_MAS],
                       columns=['mean_ln_k_assim', 'mean_ln_k_eks', 'mean_ln_kontr', 'mean_ln_en_k',
                                'min_ln_k_assim', 'min_ln_k_eks', 'min_ln_kontr', 'min_ln_en_k',
                                'max_ln_k_assim', 'max_ln_k_eks', 'max_ln_kontr', 'max_ln_en_k',
                                'intens_p_k_assim', 'intens_p_k_eks', 'intens_p_kontr', 'intens_p_en_k',
                                'intens_bit_k_assim', 'intens_bit_k_eks', 'intens_bit_kontr', 'intens_bit_en_k',
                                'unique_ip_k_assim', 'unique_ip_k_eks', 'unique_ip_kontr', 'unique_ip_en_k',
                                'unique_port_k_assim', 'unique_port_k_eks', 'unique_port_kontr', 'unique_port_en_k',
                                'classif'])
    # ctypes.windll.user32.MessageBoxW(0, "last.csv is created", "Notify", 0)
    dff.to_csv('./csv/last.csv', sep=',', encoding='utf-8', index=False)
    return dff, ITOG_MAS
