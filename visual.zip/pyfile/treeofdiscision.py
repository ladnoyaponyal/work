from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
import pandas as pd
from matplotlib import pyplot as plt
import numpy as np
from sklearn.decomposition import PCA
from sklearn.tree import export_graphviz
from subprocess import call
from IPython.core.display import Image, display
import pydot
from subprocess import check_call
from sklearn.metrics import accuracy_score, recall_score, precision_score


def tree(label1=None, label2=None):
    ris = pd.read_csv('./csv/last.csv', delimiter=',')
    # label1 = 'mean_ln_kontr'
    # label2 = 'mean_ln_en_k'
    # new = pd.DataFrame(ris[label1], columns=[label1])
    # new[label2] = ris[label2]

    X = ris.drop('classif', axis='columns')
    train_data = X
    train_labels = ris['classif']
    train_data = train_data.to_numpy()
    train_labels = train_labels.to_numpy()

    pca = PCA(n_components=2)
    train_data = pca.fit_transform(train_data)
    print('X fit:', train_data)

    # plt.rcParams['figure.figsize'] = (10, 8)
    # plt.scatter(train_data[:, 0], train_data[:, 1], c=train_labels, s=100,
    #             edgecolors='black')
    # plt.plot(range(-2, 5), range(4, -3, -1))
    # plt.savefig('trree.png')
    # plt.show()

    # Напишем вспомогательную функцию, которая будет возвращать решетку для дальнейшей визуализации.
    def get_grid(data):
        x_min, x_max = data[:, 0].min() - 1, data[:, 0].max() + 1
        y_min, y_max = data[:, 1].min() - 1, data[:, 1].max() + 1
        return np.meshgrid(np.arange(x_min, x_max, 0.01), np.arange(y_min, y_max, 0.01))

    # параметр min_samples_leaf указывает, при каком минимальном количестве
    # элементов в узле он будет дальше разделяться

    X_train, X_test, y_train, y_test = train_test_split(train_data, train_labels, test_size=0.3,
                                                        random_state=17)
    tree = DecisionTreeClassifier(criterion='entropy',max_depth=8, random_state=515,
                                  max_leaf_nodes=28, min_samples_leaf=1)
    # обучаем дерево
    tree.fit(X_train, y_train)
    tree_pred = tree.predict(X_test)
    # немного кода для отображения разделяющей поверхности
    xx, yy = get_grid(X_train)
    predicted = tree.predict(np.c_[xx.ravel(), yy.ravel()]).reshape(xx.shape)
    plt.pcolormesh(xx, yy, predicted, cmap='autumn', shading='auto')
    plt.scatter(X_train[:, 0], X_train[:, 1], c=y_train, s=100,
                cmap='autumn', edgecolors='black', linewidth=1.5)
    plt.show()
    print('дерево решений', tree.score(X_train, y_train))

    dotfile = open("../dtree2.dot", 'w')
    export_graphviz(tree, out_file=dotfile)
    dotfile.close()

    # check_call(['dot', '-Tpng', 'dtree2.dot', '-o', 'OutputFile.png'])

    (graphs,) = pydot.graph_from_dot_file('../dtree2.dot')
    graphs.write_png('f.png')
    ac = accuracy_score(y_test, tree_pred)
    pr = precision_score(y_test, tree_pred)
    re = recall_score(y_test, tree_pred)
    return ac, pr, re
    # Image('f.png', unconfined=True)


